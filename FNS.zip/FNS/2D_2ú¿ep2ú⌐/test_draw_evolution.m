% clear;clc;
% load('U2_1.mat');
% load('U1_1.mat');
% load('Tmesh1.mat');

Ly=1; Lx=1; N=128;
nu=1e-4; alpha=0.8;
T=1; eta=1e0;
Nx=N; Ny=N; hx=Lx/Nx; hy=Ly/Ny;
Xmesh=0:hx:Lx-hx; Ymesh=0:hy:Ly-hy;
Xmesh=kron(ones(Ny,1),Xmesh);
Ymesh=kron(ones(1,Nx),Ymesh');

Qx=1i*2*pi/Lx*([0:1:Nx/2-1,-Nx/2:1:-1]); 
Qy=1i*2*pi/Ly*([0:1:Ny/2-1,-Ny/2:1:-1]);
Kx=kron(ones(Ny,1),Qx); Ky=kron(ones(1,Nx),Qy(:));

figure(1)
subplot(2,3,1)
k=1;
u10=U1(:,:,k); u20=U2(:,:,k);
temp=Kx.*fft2(u20)-Ky.*fft2(u10);
disp(Tmesh(k))
pcolor(Xmesh,Ymesh,real(ifft2(temp)));
title('T=0')
set(gca,'FontSize',14)
shading interp

subplot(2,3,2)
k=2201;
u10=U1(:,:,k); u20=U2(:,:,k);
temp=Kx.*fft2(u20)-Ky.*fft2(u10);
disp(Tmesh(k))
pcolor(Xmesh,Ymesh,real(ifft2(temp)));
title('T=0.2')
set(gca,'FontSize',14)
shading interp

subplot(2,3,3)
k=3201;
u10=U1(:,:,k); u20=U2(:,:,k);
temp=Kx.*fft2(u20)-Ky.*fft2(u10);
disp(Tmesh(k))
pcolor(Xmesh,Ymesh,real(ifft2(temp)));
title('T=0.3')
set(gca,'FontSize',14)
shading interp

subplot(2,3,4)
k=4201;
u10=U1(:,:,k); u20=U2(:,:,k);
temp=Kx.*fft2(u20)-Ky.*fft2(u10);
disp(Tmesh(k))
pcolor(Xmesh,Ymesh,real(ifft2(temp)));
title('T=0.4')
set(gca,'FontSize',14)
shading interp

subplot(2,3,5)
k=5201;
u10=U1(:,:,k); u20=U2(:,:,k);
temp=Kx.*fft2(u20)-Ky.*fft2(u10);
disp(Tmesh(k))
pcolor(Xmesh,Ymesh,real(ifft2(temp)));
title('T=0.5')
set(gca,'FontSize',14)
shading interp

subplot(2,3,6)
k=6201;
u10=U1(:,:,k); u20=U2(:,:,k);
temp=Kx.*fft2(u20)-Ky.*fft2(u10);
disp(Tmesh(k))
pcolor(Xmesh,Ymesh,real(ifft2(temp)));
title('T=0.6')
set(gca,'FontSize',14)
shading interp