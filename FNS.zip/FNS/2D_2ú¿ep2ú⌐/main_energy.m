%���������仯
clear;clc;

% Ly=1; Lx=1; N=32; 
% nu=0.1; alpha=0.8;
% T=100; eta=1e1;
% 
% [Energy,Mass,Tmesh]=fracNS_Cal_energy(T,Ly,Lx,N,nu,eta,alpha);
% save energy81
% 
% alpha=0.5;
% 
% [Energy,Mass,Tmesh]=fracNS_Cal_energy(T,Ly,Lx,N,nu,eta,alpha);
% save energy51
% 
% alpha=0.3;
% 
% [Energy,Mass,Tmesh]=fracNS_Cal_energy(T,Ly,Lx,N,nu,eta,alpha);
% save energy31

load('energy31.mat')
E3=Energy; Tmesh3=Tmesh;
T3=Tmesh(2:end)-Tmesh(1:end-1); T3(end)=[];
M3=Mass;
E3(1)=[]; Tmesh3(1)=[]; M3(1)=[];

load('energy51.mat')
E5=Energy; Tmesh5=Tmesh;
T5=Tmesh(2:end)-Tmesh(1:end-1); T5(end)=[];
M5=Mass;
E5(1)=[]; Tmesh5(1)=[]; M5(1)=[];

load('energy81.mat')
E8=Energy; Tmesh8=Tmesh;
T8=Tmesh(2:end)-Tmesh(1:end-1); T8(end)=[];
M8=Mass;
E8(1)=[]; Tmesh8(1)=[]; M8(1)=[];

% figure(1)
% plot(Tmesh3,E3,'r-','Linewidth',2)
% hold on
% plot(Tmesh5,E5,'b-','Linewidth',2)
% hold on
% plot(Tmesh8,E8,'g-','Linewidth',2)
% hold off
% xlabel('Time')
% ylabel('Energy')
% set(gca,'FontSize',14)
% legend('\alpha=0.3','\alpha=0.5','\alpha=0.8')
% 
% axes('Position',[0.20,0.40,0.2,0.4]);
% plot(Tmesh3(1:208),E3(1:208),'r-','Linewidth',2)
% hold on
% plot(Tmesh5(1:372),E5(1:372),'b-','Linewidth',2)
% hold on
% plot(Tmesh8(1:607),E8(1:607),'g-','Linewidth',2)
% %set(gca,'YTick',[0:1:2]);
% legend('\alpha=0.3','\alpha=0.5','\alpha=0.8')
% set(gca,'FontSize',8)


% 
figure(2)
subplot(1,3,1)
semilogy(Tmesh3,abs(M3))
set(gca,'YLim',[10^(-23) 10^(-19)])
xlabel('Time')
ylabel('Velocity divergence')
title('\alpha=0.3')
set(gca,'FontSize',14)

subplot(1,3,2)
semilogy(Tmesh5,abs(M5))
set(gca,'YLim',[10^(-23) 10^(-19)])
xlabel('Time')
ylabel('Velocity divergence')
title('\alpha=0.5')
set(gca,'FontSize',14)


subplot(1,3,3)
semilogy(Tmesh8,abs(M8))
set(gca,'YLim',[10^(-26) 10^(-19)])
xlabel('Time')
ylabel('Velocity divergence')
title('\alpha=0.8')
set(gca,'FontSize',14)



% figure(5)
% plot(Tmesh3(2:end),T3,'r-','Linewidth',2)
% hold on
% plot(Tmesh5(2:end),T5,'b-','Linewidth',2)
% hold on
% plot(Tmesh8(2:end),T8,'g-','Linewidth',2)
% hold off
% legend('\alpha=0.3','\alpha=0.5','\alpha=0.8')
% xlabel('Time')
% ylabel('Step-size')
% set(gca,'FontSize',14)
