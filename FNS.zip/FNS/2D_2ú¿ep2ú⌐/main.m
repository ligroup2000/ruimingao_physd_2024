clear;clc;

%convergence rate calculation
Ly=1; Lx=1; N=8; 
nu=1; alpha=[0.3;0.5;0.8]; 
T=1;

M0=16000;
M=[400;800;1600;3200];
EU1=zeros(length(M),length(alpha));  EU2=EU1; EP=EU1;

for m=1:length(alpha)
    
    delta=(2-alpha(m))/alpha(m);
    [U1_ref,U2_ref,P_ref,Tmesh_ref,~,~,~,~]=frac_NS_2D(Lx,Ly,T,M0,N,delta,alpha(m),nu);
    
    for k=1:length(M)
    
        [U1,U2,P,Tmesh,Kx,Ky,h1,h2]=frac_NS_2D(Lx,Ly,T,M(k),N,delta,alpha(m),nu);
        number=M0/M(k); t=0:1:M(k);
        error1=U1-U1_ref(:,:,number*t+1);
        error2=U2-U2_ref(:,:,number*t+1);
        errorp=P-P_ref(:,:,number*t+1);
        error_u1=zeros(length(t),1); error_u2=error_u1; error_p=error_u1;
        
        for j=1:length(t)
             error_u1(j)=sum(sum(error1(:,:,j).^2))+sum(sum(real(ifft2(Kx.*error1(:,:,j))).^2))+sum(sum(real(ifft2(Ky.*error1(:,:,j))).^2)); error_u1(j)=sqrt(h1*h2*error_u1(j));
                error_u2(j)=sum(sum(error2(:,:,j).^2))+sum(sum(real(ifft2(Kx.*error2(:,:,j))).^2))+sum(sum(real(ifft2(Ky.*error2(:,:,j))).^2)); error_u2(j)=sqrt(h1*h2*error_u2(j));
                error_p(j)=sum(sum(errorp(:,:,j).^2)); error_p(j)=sqrt(h1*h2*error_p(j));
        end
        
    
        EU1(k,m)=max(error_u1); EU2(k,m)=max(error_u2); 
        EP(k,m)=max(error_p);
        
    end
    
end

for m=1:length(alpha)
    order_u1(:,m)=log(EU1(1:end-1,m)./EU1(2:end,m))./(log(M(2:end)./M(1:end-1)));
    order_u2(:,m)=log(EU2(1:end-1,m)./EU2(2:end,m))./(log(M(2:end)./M(1:end-1)));
    order_p(:,m)=log(EP(1:end-1,m)./EP(2:end,m))./(log(M(2:end)./M(1:end-1)));
end

format shortE
disp(EU1)
disp(order_u1)
disp(EP)
disp(order_p)

%draw convex
% Ly=1; Lx=1; N=128;
% nu=1e-4; alpha=0.8;
% T=1; eta=1e0;
% 
% [U1,U2,Tmesh]=FracNS_evolu(T,Ly,Lx,N,nu,eta,alpha);
% 
% save('U1_1.mat','U1','-v7.3'); 
% save('U2_1.mat','U2','-v7.3'); 
% save('Tmesh.mat','Tmesh','-v7.3'); 

% 
% load('U1.mat')
% load('U2.mat')
% load('Tmesh.mat')
% % 
% k=3700;
% u11=U1(:,:,k); u22=U2(:,:,k);
% disp(Tmesh(k))
% 
% figure(1)
% pcolor(u11);
% shading interp;

