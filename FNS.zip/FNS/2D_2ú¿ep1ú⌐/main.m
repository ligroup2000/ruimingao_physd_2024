clear;clc;

%convergence rate calculation
Ly=2*pi; Lx=2*pi; N=8; delta=2; T=1;

nu=1; alpha=0.3;
M=[400;800;1600;3200];

EU1=zeros(length(M),1);  EU2=EU1; EP=EU1;

for k=1:length(M)
    
    [error_u1,error_u2,error_p,Mass]=frac_NS_2D(Lx,Ly,T,M(k),N,delta,alpha,nu);
    EU1(k)=max(error_u1);
    EU2(k)=max(error_u2);
    EP(k)=max(error_p);
    
end

order_u1=log(EU1(1:end-1)./EU1(2:end))./(log(M(2:end)./M(1:end-1)));
order_u2=log(EU2(1:end-1)./EU2(2:end))./(log(M(2:end)./M(1:end-1)));
order_p=log(EP(1:end-1)./EP(2:end))./(log(M(2:end)./M(1:end-1)));

format shortE
disp(EU1)
disp(order_u1)
disp(EP)
disp(order_p)

% Ly=2*pi; Lx=2*pi; N=128; 
% nu=0.0001; alpha=0.9;
% T=1; eta=1;
% 
% [U1,U2,Tmesh]=FracNS_evolu(T,Ly,Lx,N,nu,eta,alpha);
% save('U1.mat','U1','-v7.3'); 
% save('U2.mat','U2','-v7.3'); 
% save('Tmesh.mat','Tmesh','-v7.3'); 


% % 
% load('U1.mat')
% load('U2.mat')
% load('Tmesh.mat')
% 
% k=120;
% u11=U1(:,:,k); u22=U2(:,:,k);
% disp(Tmesh(k))
% 
% figure(1)
% temp=Kx.*fft2(u11)-Ky.*fft2(u22);
% pcolor(real(ifft2(temp)));
% shading interp


