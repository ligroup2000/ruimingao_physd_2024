%���������仯
clear;clc;
% 
Ly=2*pi; Lx=2*pi; N=8; 
nu=0.1; T=100; eta=10;

alpha=0.3;
[Energy,Mass,Tmesh]=fracNS_Cal_energy(T,Ly,Lx,N,nu,eta,alpha);
% 
% save alpha31

% alpha=0.5;
% [Energy,Mass,Tmesh]=fracNS_Cal_energy(T,Ly,Lx,N,nu,eta,alpha);
% % 
% save alpha51

% alpha=0.8;
% [Energy,Mass,Tmesh]=fracNS_Cal_energy(T,Ly,Lx,N,nu,eta,alpha);
% % 
% save alpha81
% load('energy.mat')
% tau=[Tmesh(2:end-1)-Tmesh(1:end-2)];
% figure(1)
% plot(1:length(tau),tau);
% figure(2)
% plot(Tmesh,Energy)
% figure(3)
% plot(Tmesh,Mass)