% clear;clc;
% load('U2.mat');
% load('U1.mat');
% load('Tmesh.mat');

Ly=2*pi; Lx=2*pi; N=128; 
nu=1e-4; alpha=0.8;
T=1; eta=1e0;
Nx=N; Ny=N; hx=Lx/Nx; hy=Ly/Ny;
Xmesh=0:hx:Lx-hx; Ymesh=0:hy:Ly-hy;
Xmesh=kron(ones(Ny,1),Xmesh);
Ymesh=kron(ones(1,Nx),Ymesh');


Qx=1i*2*pi/Lx*([0:1:Nx/2-1,-Nx/2:1:-1]); 
Qy=1i*2*pi/Ly*([0:1:Ny/2-1,-Ny/2:1:-1]);
Kx=kron(ones(Ny,1),Qx); Ky=kron(ones(1,Nx),Qy(:));

% K=[1,5001,13001,15001,length(Tmesh)];
% figure(1)
% k=K(1);
% u10=U1(:,:,k); u20=U2(:,:,k);
% disp(Tmesh(k))
% surf(Xmesh,Ymesh,u10);
% 
% figure(2)
% k=K(2);
% u10=U1(:,:,k); u20=U2(:,:,k);
% disp(Tmesh(k))
% surf(Xmesh,Ymesh,u10);
% 
% figure(3)
% k=K(3);
% u10=U1(:,:,k); u20=U2(:,:,k);
% disp(Tmesh(k))
% surf(Xmesh,Ymesh,u10);
% 
% figure(4)
% k=K(4);
% u10=U1(:,:,k); u20=U2(:,:,k);
% disp(Tmesh(k))
% surf(Xmesh,Ymesh,u10);


figure(1)
subplot(2,2,1)
k=1;
u10=U1(:,:,k); u20=U2(:,:,k);
temp=Kx.*fft2(u20)-Ky.*fft2(u10);
disp(Tmesh(k))
pcolor(Xmesh,Ymesh,real(ifft2(temp)));
title('T=0')
set(gca,'FontSize',14)
shading interp

subplot(2,2,2)
k=13001;
u10=U1(:,:,k); u20=U2(:,:,k);
temp=Kx.*fft2(u20)-Ky.*fft2(u10);
disp(Tmesh(k))
pcolor(Xmesh,Ymesh,real(ifft2(temp)));
title('T=0.4')
set(gca,'FontSize',14)
shading interp

subplot(2,2,3)
k=15001;
u10=U1(:,:,k); u20=U2(:,:,k);
temp=Kx.*fft2(u20)-Ky.*fft2(u10);
disp(Tmesh(k))
title('T=0.6')
pcolor(Xmesh,Ymesh,real(ifft2(temp)));
set(gca,'FontSize',14)
shading interp


subplot(2,2,4)
k=length(Tmesh);
u10=U1(:,:,k); u20=U2(:,:,k);
temp=Kx.*fft2(u20)-Ky.*fft2(u10);
disp(Tmesh(k))
pcolor(Xmesh,Ymesh,real(ifft2(temp)));
title('T=1')
set(gca,'FontSize',14)
shading interp
% 
